package com.example.demoTDDTesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTddTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTddTestingApplication.class, args);
	}

}
