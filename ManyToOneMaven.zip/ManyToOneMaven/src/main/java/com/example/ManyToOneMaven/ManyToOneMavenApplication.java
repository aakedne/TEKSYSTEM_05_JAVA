package com.example.ManyToOneMaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManyToOneMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManyToOneMavenApplication.class, args);
	}

}
