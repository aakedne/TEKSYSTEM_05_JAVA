package com.example.ManyToOneMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToOneMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
