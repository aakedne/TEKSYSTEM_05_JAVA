package com.springboot.TEKsystems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootFitsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootFitsAppApplication.class, args);
	}

}
