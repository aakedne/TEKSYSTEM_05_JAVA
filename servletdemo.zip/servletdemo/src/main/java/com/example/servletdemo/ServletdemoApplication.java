package com.example.servletdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServletdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServletdemoApplication.class, args);
	}

}
